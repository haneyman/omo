package com.omo.service;

import org.springframework.roo.addon.layers.service.RooService;

@RooService(domainTypes = { com.omo.domain.Order.class })
public interface OrderService {
}
