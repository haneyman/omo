package com.omo.service;


public class MenuServiceImpl implements MenuService {
}
