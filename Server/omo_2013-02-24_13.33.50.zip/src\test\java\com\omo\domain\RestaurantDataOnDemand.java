package com.omo.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Restaurant.class)
public class RestaurantDataOnDemand {
}
