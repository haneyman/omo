package com.omo.service;


public class OrderServiceImpl implements OrderService {
}
