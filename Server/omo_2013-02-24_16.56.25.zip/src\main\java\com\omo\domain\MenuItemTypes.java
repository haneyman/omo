package com.omo.domain;


public enum MenuItemTypes {

    MenuGroup, MenuItem;
}
